import contactRoutes from './contactRoutes.js'
import enquiryRoutes from './enquiryRoutes.js'
import countRoutes from './countRoutes.js'

export {  contactRoutes,enquiryRoutes,countRoutes};